/******************************************************************************

	TL hslib common
	
	2008-12-16	created by kong
	2010-11-11	modify by andyrew

******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#include "hi_common.h"
#include "hi_comm_video.h"
#include "hi_comm_sys.h"
#include "hi_comm_vo.h"
#include "hi_comm_vi.h"
#include "mpi_sys.h"
#include "mpi_vb.h"
#include "mpi_vi.h"
#include "mpi_vo.h"
#include "mpi_venc.h"

#include "loadbmp.h"
#include "hifb.h"

#include "lib_common.h"
#include "common.h"
#include "lib_venc.h"

#ifdef HI3535
#else
static unsigned int gSnapChn = 0;
static unsigned int gSnapStatus = 0;

#define PRE_MALLOC_MAX_PACK	10
static VENC_PACK_S pre_malloc_max_pack[PRE_MALLOC_MAX_PACK];
#endif

const HI_U8 g_SOI[2] = {0xFF, 0xD8};
const HI_U8 g_EOI[2] = {0xFF, 0xD9};

typedef struct
{
    VENC_GRP VeGroup;   /*snap group*/
	VENC_CHN SnapChn;   /*snap venc chn*/
	VPSS_CHN VpssChn;	/*snap vpss chn*/
	VPSS_GRP VpssGrp;	/*snap vpss group*/
	VI_DEV ViDev;       /*vi device,it has the vichn which snap group bind to*/  
	VI_CHN ViChn;       /*vi channel which snap group binded to*/
	HI_U32 in_len;
	HI_U8 *in_buf;
	HI_U32 ret_len;
}SAMPLE_SNAP_THREAD_ATTR;

HI_S32 GetSnapShotBuffer(VENC_CHN SnapChn, HI_U32 in_len, HI_U8 *in_buf, HI_U32 *out_len)
{
#ifdef HI3535
	return HI_FAILURE;
#else
	HI_S32 s32Ret;
	HI_S32 s32VencFd;
	VENC_CHN_STAT_S stStat;
	VENC_STREAM_S stStream;
	fd_set read_fds;
	int total_size, k;
	
	*out_len = 0;
	
	s32VencFd = HI_MPI_VENC_GetFd(SnapChn);
	if(s32VencFd < 0)
	{
		printf("HI_MPI_VENC_GetFd err \n");
		return HI_FAILURE;
	}
	
	FD_ZERO(&read_fds);
	FD_SET(s32VencFd,&read_fds);
	
	s32Ret = select(s32VencFd+1, &read_fds, NULL, NULL, NULL);
	if(s32Ret < 0)
	{
		printf("select err\n");
		return HI_FAILURE;
	}
	else if(0 == s32Ret)
	{
		printf("time out\n");
		return HI_FAILURE;
	}
	else
	{
		if(FD_ISSET(s32VencFd, &read_fds))
		{
			s32Ret = HI_MPI_VENC_Query(SnapChn, &stStat);
			if(s32Ret != HI_SUCCESS)
			{
				printf("HI_MPI_VENC_Query:0x%x\n",s32Ret);
				return HI_FAILURE;
			}
			
			if(stStat.u32CurPacks > PRE_MALLOC_MAX_PACK)
			{
				stStream.pstPack = (VENC_PACK_S*)malloc(sizeof(VENC_PACK_S)*stStat.u32CurPacks);
				if(NULL == stStream.pstPack)
				{
					printf("malloc stream pack err!\n");
					return -1;
				}
			}
			else
			{
				stStream.pstPack = pre_malloc_max_pack;
			}
			
			stStream.u32PackCount = stStat.u32CurPacks;
			
			s32Ret = HI_MPI_VENC_GetStream(SnapChn, &stStream, HI_TRUE);
			if(HI_SUCCESS != s32Ret)
			{
				printf("HI_MPI_VENC_GetStream:0x%x\n",s32Ret);
				if(stStat.u32CurPacks > PRE_MALLOC_MAX_PACK)
				{
					free(stStream.pstPack);
				}
				stStream.pstPack = NULL;
				return HI_FAILURE;
			}
			
			{
				VENC_STREAM_S *pstStream = &stStream;
				
				total_size = sizeof(g_SOI)+sizeof(g_EOI);
				for(k = 0; k < pstStream->u32PackCount; k++)
				{
					total_size = total_size + pstStream->pstPack[k].u32Len[0] + ((pstStream->pstPack[k].u32Len[1] > 0) ? pstStream->pstPack[k].u32Len[1]:0);
				}
				
				if(total_size <= in_len)
				{
					memcpy(in_buf, g_SOI, sizeof(g_SOI));
					total_size = sizeof(g_SOI);
					
					for(k = 0; k < pstStream->u32PackCount; k++)
					{
						memcpy(in_buf + total_size, pstStream->pstPack[k].pu8Addr[0], pstStream->pstPack[k].u32Len[0]);
						total_size += pstStream->pstPack[k].u32Len[0];
						if(pstStream->pstPack[k].u32Len[1] > 0)
						{
							memcpy(in_buf+total_size, pstStream->pstPack[k].pu8Addr[1], pstStream->pstPack[k].u32Len[1]);
							total_size += pstStream->pstPack[k].u32Len[1];
						}
					}
					memcpy(in_buf+total_size, g_EOI, sizeof(g_EOI));
					total_size += sizeof(g_SOI);
					*out_len = total_size;
				}
				else
				{
					printf("GetSnapShotBuffer: buffer too small\n");
					return HI_FAILURE;
				}
			}
			
			s32Ret = HI_MPI_VENC_ReleaseStream(SnapChn,&stStream);
			if(s32Ret) 
			{
				printf("HI_MPI_VENC_ReleaseStream:0x%x\n",s32Ret);
				if(stStat.u32CurPacks > PRE_MALLOC_MAX_PACK)
				{
					free(stStream.pstPack);
				}
				stStream.pstPack = NULL;
				return HI_FAILURE;
			}
			
			if(stStat.u32CurPacks > PRE_MALLOC_MAX_PACK)
			{
				free(stStream.pstPack);
			}
			stStream.pstPack = NULL;
		}
	}
	
	return HI_SUCCESS;
#endif
}

/*****************************************************************************
 snap by mode 1
 how to snap:
 1)only creat one snap group
 2)bind to a vichn to snap and then unbind
 3)repeat 2) to snap all vichn in turn
 
 features:
 1)save memory, because only one snap group and snap channel
 2)efficiency lower than mode 2, pictures snapped will not more than 8. 
*****************************************************************************/
HI_VOID* SampleStartSnapByMode1(HI_VOID *p)
{
#ifdef HI3535
	return NULL;
#else
	HI_S32 s32Ret;
	VENC_GRP VeGroup = 0;
	VENC_CHN SnapChn = 0;
	VI_DEV ViDev = 0;
	VI_CHN ViChn = 0;
	VPSS_GRP VpssGrp = 0;
	VPSS_CHN VpssChn = 0;
	SAMPLE_SNAP_THREAD_ATTR *pThdAttr = NULL;
	
	pThdAttr = (SAMPLE_SNAP_THREAD_ATTR*)p;
	VeGroup = pThdAttr->VeGroup;
	SnapChn = pThdAttr->SnapChn;
	ViDev   = pThdAttr->ViDev;
	ViChn   = pThdAttr->ViChn;
	VpssGrp = pThdAttr->VpssGrp;
	VpssChn = pThdAttr->VpssChn;
	
	/******************************************
	step 1:  Regist Venc Channel to VencGrp
	******************************************/
	s32Ret = HI_MPI_VENC_RegisterChn(VeGroup, SnapChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("HI_MPI_VENC_RegisterChn faild with %#x!\n", s32Ret);
		return NULL;
	}
	
	/******************************************
	step 2:  Venc Chn bind to Vpss Chn
	******************************************/
	extern HI_S32 SAMPLE_COMM_VENC_BindVpss(VENC_GRP VenGrp,VPSS_GRP VpssGrp,VPSS_CHN VpssChn);
	s32Ret = SAMPLE_COMM_VENC_BindVpss(VeGroup, VpssGrp, VpssChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("SAMPLE_COMM_VENC_BindVpss failed!\n");
		return NULL;
	}
	
	/******************************************
	step 3:  Start Recv Venc Pictures
	******************************************/
	s32Ret = HI_MPI_VENC_StartRecvPic(SnapChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("HI_MPI_VENC_StartRecvPic faild with%#x!\n", s32Ret);
		return NULL;
	}
	
	/******************************************
	step 4:  recv picture
	******************************************/
	s32Ret = GetSnapShotBuffer(SnapChn, pThdAttr->in_len, pThdAttr->in_buf, &(pThdAttr->ret_len));
	if(s32Ret != HI_SUCCESS)
	{
		printf("SampleSaveSnapPic err 0x%x\n",s32Ret);
		return NULL;
	}
	
	/******************************************
	step 1:  Stop Recv Pictures
	******************************************/
	s32Ret = HI_MPI_VENC_StopRecvPic(SnapChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("HI_MPI_VENC_StopRecvPic vechn[%d] failed with %#x!\n", SnapChn, s32Ret);
		return NULL;
	}
	
	/******************************************
	step 2:  UnRegist Venc Channel
	******************************************/
	s32Ret = HI_MPI_VENC_UnRegisterChn(SnapChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("HI_MPI_VENC_UnRegisterChn vechn[%d] failed with %#x!\n", SnapChn, s32Ret);
		return NULL;
	}
	
	extern HI_S32 SAMPLE_COMM_VENC_UnBindVpss(VENC_GRP VenGrp,VPSS_GRP VpssGrp,VPSS_CHN VpssChn);
	s32Ret = SAMPLE_COMM_VENC_UnBindVpss(VeGroup, VpssGrp, VpssChn);
	if(HI_SUCCESS != s32Ret)
	{
		LIB_PRT("SAMPLE_COMM_VENC_UnBindVpss, VeGroup=%d, VpssGrp=%d, VpssChn=%d, s32Ret=0x%x\n", VeGroup, VpssGrp, VpssChn, s32Ret);
		return NULL;
	}
	
	return NULL;
#endif
}

HI_S32 SampleDestroySnapChn(VENC_GRP VeGroup,VENC_CHN SnapChn)
{
#ifdef HI3535
	return HI_FAILURE;
#else
	HI_S32 s32Ret;
	s32Ret = HI_MPI_VENC_DestroyChn(SnapChn);
	if(s32Ret != HI_SUCCESS)
	{
		printf("HI_MPI_VENC_DestroyChn snapchn %d err 0x%x\n",SnapChn,s32Ret);
		return HI_FAILURE;
	}
	
	s32Ret = HI_MPI_VENC_DestroyGroup(VeGroup);
	if(s32Ret != HI_SUCCESS)
	{
		printf("HI_MPI_VENC_DestroyGroup snap group %d err 0x%x\n",SnapChn,s32Ret);
		return HI_FAILURE;
	}
	
	return HI_SUCCESS;
#endif
}

HI_S32 SampleCreateSnapChn(VENC_GRP VeGroup,VENC_CHN SnapChn, VENC_CHN_ATTR_S *pstAttr)
{
#ifdef HI3535
	return HI_FAILURE;
#else
	HI_S32 s32Ret;
	
	/*����ץ��ͨ��*/
	s32Ret = HI_MPI_VENC_CreateGroup(VeGroup);
	if(s32Ret != HI_SUCCESS)
	{
		printf("HI_MPI_VENC_CreateGroup err 0x%x\n",s32Ret);
		return HI_FAILURE;
	}
	
	s32Ret = HI_MPI_VENC_CreateChn(SnapChn,pstAttr);
	if(s32Ret != HI_SUCCESS)
	{
		printf("HI_MPI_VENC_CreateChn err 0x%x\n",s32Ret);
		return HI_FAILURE;
	}
	
	return HI_SUCCESS;
#endif
}

int tl_1CIFJpeg_Init(void)
{
#ifdef HI3535
	return -1;
#else
	VENC_GRP SnapGrpId = 0;
	VENC_CHN SnapChn = 0;
	VENC_CHN_ATTR_S stAttr;
	VENC_ATTR_JPEG_S stJpegAttr;
	
	/*jpeg chn attr*/
	stAttr.stVeAttr.enType = PT_JPEG;
	stJpegAttr.u32MaxPicWidth  = 352;
	stJpegAttr.u32MaxPicHeight = 288;
	stJpegAttr.u32PicWidth  = 352;
	stJpegAttr.u32PicHeight = 288;
	stJpegAttr.u32BufSize = 352*288*2;
	stJpegAttr.bByFrame = HI_TRUE;/*get stream mode is field mode  or frame mode*/
	stJpegAttr.bVIField = HI_FALSE;/*the sign of the VI picture is field or frame?*/
	stJpegAttr.u32Priority = 0;/*channels precedence level*/
	memcpy(&stAttr.stVeAttr.stAttrJpeg, &stJpegAttr, sizeof(VENC_ATTR_JPEG_S));
	
	if(gSnapStatus)
	{
		printf("lib_snapshot.c: Already init...\n");
		return -1;
	}
	
	gSnapChn = ARG_VI_NUM_MAX*2+1;
	
	SnapGrpId = gSnapChn;
	SnapChn   = gSnapChn;
	if(HI_SUCCESS != SampleCreateSnapChn(SnapGrpId,SnapChn,&stAttr))
	{
		return -1;
	}
	
	gSnapStatus = 1;
	
	return 0;
#endif
}

int tl_1CIFJpeg_Capture(int Chn, unsigned char *in_buf, unsigned int in_len)
{
#ifdef HI3535
	return -1;
#else
	VI_DEV ViDev = 0;
	VI_CHN ViChn = 0;
	SAMPLE_SNAP_THREAD_ATTR stThdAttr;
	HI_S32 ch_max = ARG_VI_NUM_MAX;
	VPSS_GRP VpssGrp = 0;
	
	if((Chn < 0) || (Chn >= ch_max))
	{
		printf("Jpeg_Capture: invalid chn=%d\n", Chn);
		return -1;
	}
	
	if(gSnapStatus == 0)
	{
		printf("lib_snapshot.c: Please init snapshot first\n");
		return -1;
	}
	
	//vi_chn_adjust(Chn, &ViDev, &ViChn, &VpssGrp);
	
	stThdAttr.VeGroup = gSnapChn;
	stThdAttr.SnapChn = gSnapChn;
	stThdAttr.VpssGrp = VpssGrp;
	stThdAttr.VpssChn = VPSS_PRE0_CHN;
	stThdAttr.ViDev = ViDev;
	stThdAttr.ViChn = ViChn;
	
	stThdAttr.in_len = in_len;
	stThdAttr.in_buf = in_buf;
	stThdAttr.ret_len = 0;
	
	SampleStartSnapByMode1(&stThdAttr);
	
	printf("size=%d\n", stThdAttr.ret_len);
	
	return stThdAttr.ret_len;
#endif
}

void tl_1CIFJpeg_Exit(void)
{
#ifdef HI3535
	return;
#else
	if(gSnapStatus)
	{
		SampleDestroySnapChn(gSnapChn, gSnapChn);
		gSnapStatus = 0;
	}
#endif
}

