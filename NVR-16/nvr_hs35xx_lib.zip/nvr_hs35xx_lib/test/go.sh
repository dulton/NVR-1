cd ../src
make clean;make
cd -

make clean;make

